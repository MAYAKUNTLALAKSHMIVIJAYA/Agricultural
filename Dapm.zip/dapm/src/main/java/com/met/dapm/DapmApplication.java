package com.met.dapm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DapmApplication {

	public static void main(String[] args) {
		SpringApplication.run(DapmApplication.class, args);
	}

}
