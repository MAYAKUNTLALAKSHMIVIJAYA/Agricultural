package com.met.dapm.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.met.dapm.model.ContactUs;

public interface ContactUsRepository extends JpaRepository<ContactUs, Integer> {

}
