package com.met.dapm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DapmApplicationTests {

	@Test
	void contextLoads() {
	}

}
